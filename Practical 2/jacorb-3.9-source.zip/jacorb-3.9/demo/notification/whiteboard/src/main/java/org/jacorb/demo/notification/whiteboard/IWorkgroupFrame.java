package org.jacorb.demo.notification.whiteboard;

import java.util.List;
import java.awt.Frame;

public interface IWorkgroupFrame {
    List getList();
    Frame getFrame();
}
