This test is used to determine the scalability limitation for a single ORB
to serve thousands of servants. The test works with Active Object Maps,
Servant Managers, and Default Servants.
